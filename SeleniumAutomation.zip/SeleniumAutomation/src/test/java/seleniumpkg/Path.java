package seleniumpkg;

public class Path {
    public static final String FACEBOOK_URL = "https://facebook.com";
//    public static final String CHROME_DRIVER_PATH = "C:\\browserdrivers\\chromedriver.exe";
}
