//package pom.pageobjects;
//
//import org.openqa.selenium.By;
//import org.openqa.selenium.WebDriver;
//import org.openqa.selenium.chrome.ChromeDriver;
//
//public class landingPage {
//
//	WebDriver driver = new ChromeDriver ();
//	
////	driver.get("https://demo.nopcommerce.com/");
//	driver.get("https://rahulshettyacademy.com/locatorspractice/");
//	System.out.print(driver.getCurrentUrl());
//	
//
//	
//// ====== Element Actions =======
//	driver.findElement(By.id("inputUsername")).sendKeys("rahulshettyacademy");
//	driver.findElement(By.id("inputUsername")).clear();
//	driver.findElement(By.id("inputUsername")).sendKeys("rahulshettyacademy");
//	driver.findElement(By.name("inputPassword")).sendKeys("rahulshettyacademy");
//	
//}
